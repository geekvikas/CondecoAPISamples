var express = require('express');
var router = express.Router();
var crypto = require('crypto');
var request = require('request');
var express = require('express');
var router = express.Router();
var passport = require('passport');
var reqpro = require('request-promise');


router.get('/', function(req, res, next) {
  res.render('index', { title: 'Condeco API Samples' });
});


module.exports = router;
