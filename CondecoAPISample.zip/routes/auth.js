var express = require('express');
var router = express.Router();
var crypto = require('crypto');
var request = require('request');
var express = require('express');
var router = express.Router();
var passport = require('passport');
var reqpro = require('request-promise');
var utils = require('../lib/utils.js');


router.post('/',function(req,res,next){

        var clientName = req.body.clientName;
        var serverName = req.body.serverName;
        
        if(typeof clientName != 'undefined' && clientName.trim().length>0)
            clientName = clientName + '.';
        else
            clientName = '';

        global.client_url = clientName + serverName;
console.log(global.client_url)
        request('https://' + client_url + '/MobileAPI/DeskBookingService.svc/Configuration/GetGlobalSettings', function (error, response, body) {


            if (!error && response.statusCode == 200) {
                response = utils.decryptJson(JSON.parse(body));
				console.log(response);
                if(response.CallResponse.ResponseCode===100)
                {
                    global.oauth_url = response.PingOAuthURL;
                    global.client_id = response.PingOAuthClientID;
                    
                    var magic_url = response.PingOAuthURL + '/as/authorization.oauth2?&idp=' + response.PingOAuthIdpAdapterID + '&prompt=login&response_type=code&scope=openid&code_challenge=&redirect_uri=http%3A%2F%2Flocalhost%3A15938%2Fsignin-pingfederate&client_id=' + response.PingOAuthClientID;
                    res.redirect(magic_url);
                }
            }
        });
    
});

module.exports = router;
