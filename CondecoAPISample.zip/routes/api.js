var express = require('express');
var router = express.Router();
var request = require('request');
var express = require('express');
var router = express.Router();
var passport = require('passport');
var reqpro = require('request-promise');

router.get('/MyBookings', function(req, res) {
      var bearer = global.bearer;
      
        if(typeof bearer === 'undefined' || bearer.trim().length == 0 )
            res.redirect('/?err=Unauthorized');
        else
            res.send(bearer);
    //   var options = {
    //     method: 'GET',
    //     uri: global.serverUrl + '',
    //     form: {
    //           grant_type: 'authorization_code',
    //           client_id: global.client_id,
    //           client_secret: '',
    //           redirect_uri: 'http://localhost:15938/signin-pingfederate',
    //           code:oauth_code
    //     },
    //     json: true  
    // };
    
    // reqpro(options)
    //     .then(function (body) {
    //         res.send(body);
    //     })
    //     .catch(function (err) {
    //       res.send(err);
    //     });

    
      

});

module.exports = router;
